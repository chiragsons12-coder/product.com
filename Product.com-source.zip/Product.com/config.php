<?php
declare(strict_types=1);

define('APP_NAME', 'Product.com');
define('APP_ENV', 'development'); // change to production before launch
define('APP_DEBUG', true);        // change to false before launch
define('CURRENCY', '₹');
define('PYTHON_API_URL', '');     // optional, e.g. https://your-api.onrender.com

$dbHost = '127.0.0.1';
$dbName = 'product_com';
$dbUser = 'root';
$dbPass = '';

if (APP_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(0);
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => $secure]);
    session_start();
}

try {
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit(APP_DEBUG ? 'Database connection failed: ' . htmlspecialchars($e->getMessage()) : 'Database unavailable. Please try again later.');
}
