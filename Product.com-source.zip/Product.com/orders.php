<?php
require 'config.php';require 'includes/functions.php';require_login();
$s=$pdo->prepare("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC");$s->execute([current_user()['id']]);$orders=$s->fetchAll();
$pageTitle='My orders';require 'includes/header.php';?>
<h1>My orders</h1><?php if(isset($_GET['placed'])): ?><div class="alert success">Order #<?= (int)$_GET['placed'] ?> placed successfully. Payment is Cash on Delivery.</div><?php endif; ?>
<?php if(!$orders): ?><div class="panel">You haven't placed any orders yet. <a href="index.php">Start shopping</a>.</div><?php endif; ?>
<?php foreach($orders as $o): ?><div class="panel"><div class="section-head"><div><strong>Order #<?= (int)$o['id'] ?></strong><div class="muted"><?= e($o['created_at']) ?></div></div><span class="badge"><?= e($o['status']) ?></span></div><div>Total: <strong><?= money($o['total']) ?></strong> · <?= e($o['payment_method']) ?></div>
<?php $it=$pdo->prepare("SELECT * FROM order_items WHERE order_id=?");$it->execute([$o['id']]);foreach($it->fetchAll() as $line): ?><p><?= e($line['product_name']) ?> × <?= (int)$line['quantity'] ?> — <?= money($line['price']*$line['quantity']) ?></p><?php endforeach; ?></div><?php endforeach; ?>
<?php require 'includes/footer.php'; ?>
