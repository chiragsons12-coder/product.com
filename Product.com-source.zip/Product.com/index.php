<?php
require 'config.php'; require 'includes/functions.php';
$q = trim($_GET['q'] ?? ''); $cat = trim($_GET['category'] ?? '');
$sql = "SELECT * FROM products WHERE active=1"; $args=[];
if ($q !== '') { $sql .= " AND (name LIKE ? OR description LIKE ? OR category LIKE ?)"; $args = ["%$q%","%$q%","%$q%"]; }
if ($cat !== '') { $sql .= " AND category=?"; $args[]=$cat; }
$sql .= " ORDER BY created_at DESC";
$st=$pdo->prepare($sql); $st->execute($args); $products=$st->fetchAll();
$cats=$pdo->query("SELECT DISTINCT category FROM products WHERE active=1 ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
$pageTitle='Shop'; require 'includes/header.php';
?>
<section class="hero"><div><span class="pill">Welcome to Product.com</span><h1>Find your next<br>everyday favourite.</h1><p>Discover useful products, great value and a simple shopping experience.</p><a class="btn" href="#products">Explore products</a></div><div class="hero-art" style="font-size:100px">🛍️</div></section>
<div class="section-head" id="products"><div><h2>Shop products</h2><div class="muted"><?= count($products) ?> items available</div></div></div>
<div class="admin-links" style="margin-bottom:18px"><a class="badge" href="index.php">All</a><?php foreach($cats as $c): ?><a class="badge" href="?category=<?= urlencode($c) ?>"><?= e($c) ?></a><?php endforeach; ?></div>
<div class="grid">
<?php foreach($products as $p): ?><article class="product">
<img src="<?= e($p['image_url']) ?>" alt="<?= e($p['name']) ?>" loading="lazy">
<div class="product-body"><span class="muted" style="font-size:12px"><?= e($p['category']) ?></span><h3><?= e($p['name']) ?></h3><div><span class="price"><?= money($p['price']) ?></span><?php if($p['compare_price']): ?><span class="old"><?= money($p['compare_price']) ?></span><?php endif; ?></div>
<p class="muted" style="font-size:13px;min-height:38px"><?= e($p['description']) ?></p>
<div class="product-actions"><form method="post" action="cart.php"><?= csrf_field() ?><input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="action" value="add"><button>Add to cart</button></form></div></div></article><?php endforeach; ?>
</div>
<?php if(!$products): ?><div class="panel">No products found. Try another search.</div><?php endif; ?>
<?php require 'includes/footer.php'; ?>
