# Product.com — PHP / MySQL e-commerce starter

A responsive starter store with PHP sessions, MySQL, customer registration/login, product search, cart, cash-on-delivery checkout, order history, and an admin area. A small Flask service is included as an optional Python companion API.

## Stack
- HTML5, CSS3, vanilla JavaScript
- PHP 8.1+ with PDO
- MySQL 8 / MariaDB
- Optional Python 3.10+ Flask API

## Local setup (XAMPP)
1. Install XAMPP and start Apache + MySQL.
2. Copy this folder into `C:\xampp\htdocs\Product.com` (Windows) or the equivalent `htdocs` folder.
3. Open phpMyAdmin and import `database/schema.sql`.
4. Edit `config.php` with your local database credentials. XAMPP commonly uses host `127.0.0.1`, database `product_com`, user `root`, blank password.
5. Visit `http://localhost/Product.com/setup_admin.php` and create the first admin. **Delete `setup_admin.php` immediately after creating the admin.**
6. Open `http://localhost/Product.com/`.

## Free hosting deployment
### PHP + MySQL website
InfinityFree currently advertises PHP and MySQL hosting with free SSL and a free subdomain. Create an account, create a hosting account, then:
1. Create a MySQL database in the hosting control panel. Copy its exact host, database name, username and password.
2. Import `database/schema.sql` using the host's phpMyAdmin.
3. Upload the project files and folders to the account's web root (usually `htdocs`) using the online File Manager or FTP. Do not upload the local `.env` or any private credentials.
4. Edit `config.php` with the database credentials supplied by the host. Do not assume the database host is `localhost`.
5. Visit `https://YOUR-SUBDOMAIN/setup_admin.php`, create the admin, then delete `setup_admin.php` from the server.
6. Test registration, login, adding to cart, COD checkout and admin order status updates.
7. Enable/force HTTPS in the hosting panel if available.

InfinityFree hosting details: https://www.infinityfree.com/ . Free-host limits and policies can change. Free shared hosting is suitable for learning/demo use, not a dependable production storefront.

### Optional Python Flask API
The PHP shop does not depend on Python. To deploy the optional Python API separately:
1. Push the `python_service` folder to a GitHub repository (or deploy the project root and set the root directory to `python_service`).
2. On Render create a **Web Service**, connect the repo, choose Python.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Set environment variable `API_KEY` to a long random secret. The `/health` endpoint is public; `/api/store-stats` requires `X-API-Key`.
6. Copy the Render URL into `PYTHON_API_URL` in `config.php` if you want to call the service from the PHP site.

Render free web services sleep after 15 minutes idle and may take about a minute to wake. The free tier is for hobby/testing and is not a production SLA. See https://render.com/docs/free and https://render.com/docs/deploy-flask .

## Admin and security checklist
- Use HTTPS.
- Delete `setup_admin.php` after setup.
- Change all default/demo credentials (none are hard-coded).
- Set `APP_ENV` to `production` and `APP_DEBUG` to `false` in `config.php`.
- Use a strong unique DB password and keep backups.
- Configure a transactional email provider before relying on order emails (email sending is not configured).
- Integrate a PCI-compliant payment provider (Razorpay/Stripe) before accepting online payments. This starter only implements Cash on Delivery.
- Add privacy policy, terms, shipping/returns policy, GST/tax rules, inventory controls, rate limiting, monitoring and regular backups before real commercial use.

## Notes
- Prices are stored as INR decimal values.
- The checkout uses Cash on Delivery and records an order in MySQL; it does not charge a payment card.
- Product image URLs are demo Unsplash images. Replace them with your own licensed product images.
- Python API is a separate optional service. Do not expose its API key in browser JavaScript.
