document.addEventListener('click',e=>{const el=e.target.closest('[data-confirm]');if(el&&!confirm(el.dataset.confirm))e.preventDefault();});
document.querySelectorAll('[data-qty]').forEach(input=>input.addEventListener('change',()=>{if(input.form)input.form.submit();}));
