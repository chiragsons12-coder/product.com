import os
from flask import Flask, jsonify, request

app = Flask(__name__)
API_KEY = os.environ.get("API_KEY", "")

@app.get("/health")
def health():
    return jsonify({"service": "product-com-python-api", "status": "ok"})

@app.get("/api/store-stats")
def store_stats():
    if not API_KEY or request.headers.get("X-API-Key") != API_KEY:
        return jsonify({"error": "unauthorized"}), 401
    # This endpoint is intentionally a protected integration placeholder.
    # Connect a read-only database client here only if you need Python-side analytics.
    return jsonify({"message": "Python companion API is running", "integration": "ready"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
