CREATE DATABASE IF NOT EXISTS product_com CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE product_com;
CREATE TABLE IF NOT EXISTS users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS products (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(180) NOT NULL,
 slug VARCHAR(200) NOT NULL UNIQUE,
 description TEXT NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 compare_price DECIMAL(10,2) DEFAULT NULL,
 image_url VARCHAR(500) NOT NULL,
 category VARCHAR(100) NOT NULL DEFAULT 'General',
 stock INT NOT NULL DEFAULT 20,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_products_category(category), INDEX idx_products_active(active)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS orders (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 full_name VARCHAR(150) NOT NULL,
 email VARCHAR(190) NOT NULL,
 phone VARCHAR(30) NOT NULL,
 address TEXT NOT NULL,
 city VARCHAR(100) NOT NULL,
 postal_code VARCHAR(20) NOT NULL,
 total DECIMAL(10,2) NOT NULL,
 payment_method VARCHAR(40) NOT NULL DEFAULT 'Cash on Delivery',
 status ENUM('Pending','Confirmed','Shipped','Delivered','Cancelled') NOT NULL DEFAULT 'Pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_orders_user FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS order_items (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id BIGINT UNSIGNED NOT NULL,
 product_id INT UNSIGNED NULL,
 product_name VARCHAR(180) NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 quantity INT NOT NULL,
 CONSTRAINT fk_items_order FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
 CONSTRAINT fk_items_product FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO products(name,slug,description,price,compare_price,image_url,category,stock) VALUES
('Wireless Headphones','wireless-headphones','Comfortable over-ear headphones with rich sound and a long-lasting battery.',1499,2199,'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800','Electronics',25),
('Classic Sneakers','classic-sneakers','Everyday sneakers designed for comfort and casual style.',1999,2799,'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800','Fashion',18),
('Smart Watch','smart-watch','A clean, modern smartwatch for everyday activity tracking.',2499,3299,'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800','Electronics',14),
('Travel Backpack','travel-backpack','Versatile backpack with practical storage for work and travel.',1199,1599,'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800','Accessories',30),
('Sunglasses','sunglasses','Lightweight everyday sunglasses with a timeless silhouette.',799,1099,'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800','Fashion',40),
('Desk Lamp','desk-lamp','Minimal desk lamp for focused work and comfortable reading.',999,1399,'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800','Home',12),
('Coffee Maker','coffee-maker','Compact coffee maker for a simple morning routine.',2299,2999,'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800','Home',9),
('Fitness Bottle','fitness-bottle','Reusable bottle for the gym, office and everyday hydration.',399,599,'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800','Accessories',50);
