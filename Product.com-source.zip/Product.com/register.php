<?php
require 'config.php'; require 'includes/functions.php';verify_csrf();$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
$name=trim($_POST['name']??'');$email=strtolower(trim($_POST['email']??''));$pass=$_POST['password']??'';
if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<8)$error='Enter a name, valid email and password of at least 8 characters.';
else{try{$s=$pdo->prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)");$s->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);$_SESSION['user']=['id'=>(int)$pdo->lastInsertId(),'name'=>$name,'email'=>$email,'role'=>'customer'];redirect('index.php');}catch(PDOException $e){$error='That email address may already be registered.';}}
}
$pageTitle='Create account';require 'includes/header.php';?>
<div class="panel form-wrap"><h1>Create account</h1><?php if($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?><form method="post"><?= csrf_field() ?><div class="field"><label>Name</label><input name="name" required maxlength="120"></div><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Password (8+ characters)</label><input type="password" name="password" minlength="8" required></div><button>Create account</button></form><p class="muted">Already registered? <a href="login.php">Login</a></p></div>
<?php require 'includes/footer.php'; ?>
