<?php $pageTitle = $pageTitle ?? APP_NAME; ?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/style.css">
</head><body>
<header class="topbar"><div class="container nav">
<a class="brand" href="index.php">Product<span>.com</span></a>
<form class="search" action="index.php" method="get"><input name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Search products..."><button aria-label="Search">Search</button></form>
<nav>
<a href="index.php">Shop</a><a href="cart.php">Cart (<?= cart_count() ?>)</a>
<?php if (current_user()): ?>
<a href="orders.php">My orders</a>
<?php if (($_SESSION['user']['role'] ?? '') === 'admin'): ?><a href="admin.php">Admin</a><?php endif; ?>
<a href="logout.php">Logout</a>
<?php else: ?><a href="login.php">Login</a><a class="nav-cta" href="register.php">Sign up</a><?php endif; ?>
</nav></div></header><main class="container">
