<?php
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function money($value): string { return CURRENCY . number_format((float)$value, 2); }
function redirect(string $url): never { header('Location: ' . $url); exit; }
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $sent = $_POST['csrf'] ?? '';
        if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
            http_response_code(419); exit('Your session expired. Please go back and try again.');
        }
    }
}
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void { if (!current_user()) redirect('login.php'); }
function require_admin(): void {
    require_login();
    if (($_SESSION['user']['role'] ?? '') !== 'admin') { http_response_code(403); exit('Forbidden'); }
}
function cart_count(): int {
    $n = 0; foreach (($_SESSION['cart'] ?? []) as $qty) $n += (int)$qty; return $n;
}
function cart_items(PDO $pdo): array {
    $cart = $_SESSION['cart'] ?? [];
    if (!$cart) return [];
    $ids = array_values(array_filter(array_map('intval', array_keys($cart))));
    if (!$ids) return [];
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT * FROM products WHERE active=1 AND id IN ($marks)");
    $st->execute($ids);
    $items = [];
    foreach ($st->fetchAll() as $p) {
        $qty = max(1, min(20, (int)($cart[$p['id']] ?? 1)));
        $p['quantity'] = $qty; $p['line_total'] = $qty * (float)$p['price'];
        $items[] = $p;
    }
    return $items;
}
function cart_total(array $items): float {
    return array_reduce($items, fn($sum, $p) => $sum + (float)$p['line_total'], 0.0);
}
