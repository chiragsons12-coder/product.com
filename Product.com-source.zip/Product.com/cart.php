<?php
require 'config.php'; require 'includes/functions.php'; verify_csrf();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $id=(int)($_POST['product_id']??0); $action=$_POST['action']??'';
  if($action==='add' && $id>0){$s=$pdo->prepare("SELECT id,stock FROM products WHERE id=? AND active=1");$s->execute([$id]);$p=$s->fetch();if($p && $p['stock']>0)$_SESSION['cart'][$id]=min(20,(int)($_SESSION['cart'][$id]??0)+1);}
  if($action==='update'){foreach(($_POST['qty']??[]) as $pid=>$qty){$pid=(int)$pid;$qty=(int)$qty;if($qty<=0)unset($_SESSION['cart'][$pid]);else $_SESSION['cart'][$pid]=min(20,$qty);}}
  if($action==='remove'){unset($_SESSION['cart'][$id]);}
  redirect('cart.php');
}
$items=cart_items($pdo);$total=cart_total($items);$pageTitle='Your cart';require 'includes/header.php';
?>
<h1>Your shopping cart</h1>
<?php if(!$items): ?><div class="panel"><p>Your cart is empty.</p><a class="btn" href="index.php">Continue shopping</a></div><?php else: ?>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="update"><div class="panel table-wrap"><table><thead><tr><th>Product</th><th>Price</th><th>Quantity</th><th>Total</th><th></th></tr></thead><tbody>
<?php foreach($items as $p): ?><tr><td><img class="cart-img" src="<?= e($p['image_url']) ?>" alt=""> <?= e($p['name']) ?></td><td><?= money($p['price']) ?></td><td><input data-qty type="number" min="0" max="20" name="qty[<?= (int)$p['id'] ?>]" value="<?= (int)$p['quantity'] ?>" style="width:78px"></td><td><?= money($p['line_total']) ?></td><td><button class="danger" form="remove<?= (int)$p['id'] ?>">Remove</button></td></tr><?php endforeach; ?>
</tbody></table><p><button class="secondary">Update cart</button></p></div></form>
<?php foreach($items as $p): ?><form id="remove<?= (int)$p['id'] ?>" method="post" style="display:none"><?= csrf_field() ?><input name="action" value="remove"><input name="product_id" value="<?= (int)$p['id'] ?>"></form><?php endforeach; ?>
<div class="summary panel"><div><span>Subtotal</span><strong><?= money($total) ?></strong></div><div><span>Shipping</span><strong>Free</strong></div><div class="grand"><span>Total</span><span><?= money($total) ?></span></div><a class="btn" style="width:100%;text-align:center" href="checkout.php">Proceed to checkout</a></div>
<?php endif; require 'includes/footer.php'; ?>
