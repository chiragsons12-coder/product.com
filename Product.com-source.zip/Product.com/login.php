<?php
require 'config.php'; require 'includes/functions.php';verify_csrf();$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){$email=strtolower(trim($_POST['email']??''));$s=$pdo->prepare("SELECT * FROM users WHERE email=?");$s->execute([$email]);$u=$s->fetch();if($u&&password_verify($_POST['password']??'',$u['password_hash'])){session_regenerate_id(true);$_SESSION['user']=['id'=>(int)$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']];redirect('index.php');}$error='Email or password is incorrect.';}
$pageTitle='Login';require 'includes/header.php';?>
<div class="panel form-wrap"><h1>Welcome back</h1><?php if($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?><form method="post"><?= csrf_field() ?><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Password</label><input type="password" name="password" required></div><button>Login</button></form><p class="muted">New here? <a href="register.php">Create an account</a></p></div>
<?php require 'includes/footer.php'; ?>
